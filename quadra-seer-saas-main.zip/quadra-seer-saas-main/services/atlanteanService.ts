/**
 * Atlantean Intelligence Service
 * 
 * TypeScript client for the Atlantean Backend API.
 * This replaces traditional state management with field-based intelligence.
 */

function normalizeAtlanteanApiBase(raw: string): string {
  const trimmed = String(raw).trim();

  // Relative paths used during local development.
  if (trimmed.startsWith('/')) {
    const base = trimmed.replace(/\/$/, '');
    if (base.endsWith('/api/atlantean')) {
      return base;
    }
    if (base.endsWith('/api')) {
      return `${base}/atlantean`;
    }
    if (base === '' || base === '/') {
      return '/api/atlantean';
    }
    return base;
  }

  // Absolute URLs are normalized but remain optional for local-first usage.
  try {
    const url = new URL(trimmed);
    const pathname = (url.pathname || '/').replace(/\/$/, '');

    if (pathname.endsWith('/api/atlantean')) {
      return url.toString().replace(/\/$/, '');
    }
    if (pathname.endsWith('/api')) {
      url.pathname = `${pathname}/atlantean`;
      return url.toString().replace(/\/$/, '');
    }
    if (pathname === '' || pathname === '/') {
      url.pathname = '/api/atlantean';
      return url.toString().replace(/\/$/, '');
    }
    return url.toString().replace(/\/$/, '');
  } catch {
    // Fallback: non-URL strings keep existing behavior with slash normalization.
    const base = trimmed.replace(/\/$/, '');
    if (base.endsWith('/api/atlantean')) {
      return base;
    }
    if (base.endsWith('/api')) {
      return `${base}/atlantean`;
    }
    return base;
  }
}

export function resolveAtlanteanApiBaseOrThrow(): string {
  const configured = import.meta.env.VITE_API_BASE;
  if (configured && String(configured).trim()) {
    return normalizeAtlanteanApiBase(String(configured));
  }
  return '/api/atlantean';
}

function resolveAtlanteanHealthUrlOrThrow(): string {
  return '/health';
}

function getAtlanteanApiBase(): string {
  return resolveAtlanteanApiBaseOrThrow();
}

function getAtlanteanHealthUrl(): string {
  return resolveAtlanteanHealthUrlOrThrow();
}
const ATLANTEAN_SESSION_STORAGE_KEY = 'atlantean.session_id';

function generateSessionId(): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `atl-${Date.now()}-${rand}`;
}

export function getStableSessionId(): string {
  if (typeof window === 'undefined' || !window.localStorage) {
    return 'default';
  }

  try {
    const existing = window.localStorage.getItem(ATLANTEAN_SESSION_STORAGE_KEY);
    if (existing && existing.trim()) {
      return existing;
    }

    const created = generateSessionId();
    window.localStorage.setItem(ATLANTEAN_SESSION_STORAGE_KEY, created);
    return created;
  } catch {
    return 'default';
  }
}

export function setStableSessionId(sessionId: string): string {
  const normalized = String(sessionId || '').trim();
  const effective = normalized || generateSessionId();

  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      window.localStorage.setItem(ATLANTEAN_SESSION_STORAGE_KEY, effective);
    } catch {
      // Ignore storage failures and still return the effective id.
    }
  }

  return effective;
}

export function createAndSetStableSessionId(): string {
  return setStableSessionId(generateSessionId());
}

function resolveSessionId(sessionId?: string): string {
  return sessionId || getStableSessionId();
}

export interface AtlanteanStatus {
  device_id: string;
  version: number;
  last_update: string;
  learning_capacity: number;
  cold_memory_items: number;
  fingerprint: string | null;
  field_stats: {
    phi1_mean: number;
    phi5_mean: number;
    Phi: number;
  };
  sync?: SyncStatusMetadata;
}

export interface SyncConflictCounters {
  total_merges: number;
  concurrent_merges: number;
  remote_updates_applied: number;
  noop_merges: number;
}

export interface SyncStatusMetadata {
  last_merged_device: string | null;
  last_merge_strategy: string | null;
  last_merged_at: string | null;
  conflict_counters: SyncConflictCounters;
}

export interface FieldData {
  phi1: number[][];
  phi5: number[][];
  Phi: number;
  version: number;
  timestamp: number;
  learning_capacity: number;
  stats: {
    phi1_mean: number;
    phi1_std: number;
    phi5_mean: number;
    phi5_std: number;
  };
}

export interface QueryResponse {
  response: string;
  status: AtlanteanStatus;
}

export interface ChatHistoryMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  session_id: string;
}

export interface ColdManifest {
  manifest_id: string;
  attached_at?: number;
  detached_at?: number | null;
  detached?: boolean;
  item_ids?: string[];
  metadata?: Record<string, any>;
}

export interface AtlanteanSnapshotRecord {
  id: string;
  session_id: string;
  label?: string;
  created_at?: number | string;
  version?: number;
  source?: string;
  phase_lock?: {
    phi1_mean: number;
    phi5_mean: number;
    Phi: number;
  };
  hrm?: Record<string, any>;
}

export interface ReplayIntegrityProof {
  session_id: string;
  events_total: number;
  events_verified: number;
  replay_state_hash: string | null;
  live_state_hash: string;
  match: boolean;
  valid: boolean;
  issues: Array<Record<string, any>>;
  replay_head_hash: string;
  verified_up_to_seq: number | null;
}

export interface SoulFileBundle {
  schema_version: number;
  exported_at: number;
  session_id: string;
  identity: Record<string, any> | null;
  events: Array<Record<string, any>>;
  checkpoints: Array<Record<string, any>>;
  hot_state_hash: string;
  hot_state: Record<string, any>;
  hrm_state: Record<string, any>;
}

export type LearningEventType =
  | 'user_confirmation'
  | 'user_correction'
  | 'user_positive_feedback'
  | 'user_negative_feedback'
  | 'prediction_success'
  | 'prediction_failure'
  | 'simulation_complete'
  | 'voice_session_end'
  | 'helpful_response'
  | 'unhelpful_response'
  | 'clarification_needed'
  | 'high_engagement'
  | 'low_engagement';

/**
 * Get current intelligence status
 */
export async function getStatus(sessionId?: string): Promise<AtlanteanStatus> {
  const sid = resolveSessionId(sessionId);
  const response = await fetch(`${getAtlanteanApiBase()}/status?session_id=${encodeURIComponent(sid)}`);
  if (!response.ok) {
    throw new Error(`Failed to get status: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Process user query through Atlantean-powered LLM
 * 
 * @param input User's message
 * @param llmProvider Which LLM to use (gemini, edenai, etc.)
 * @param apiKey Optional API key for the LLM provider
 * @returns LLM response and updated status
 */
export async function query(
  input: string,
  llmProvider: 'gemini' | 'edenai' | 'mock' = 'gemini',
  apiKey?: string,
  // history parameter kept for API compatibility but is no longer forwarded —
  // the backend reconstructs context from Atlantean cold memory server-side.
  _history: Array<{ role: string; content: string }> = [],
  sessionId?: string
): Promise<QueryResponse> {
  const sid = resolveSessionId(sessionId);
  const body: any = { 
    input, 
    llm_provider: llmProvider,
    session_id: sid,
  };
  
  if (apiKey) {
    body.api_key = apiKey;
  }

  // history is intentionally NOT forwarded to the backend.

  const response = await fetch(`${getAtlanteanApiBase()}/query`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  
  if (!response.ok) {
    throw new Error(`Query failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Get field visualization data
 */
export async function getFields(sessionId?: string): Promise<FieldData> {
  const sid = resolveSessionId(sessionId);
  const response = await fetch(`${getAtlanteanApiBase()}/fields?session_id=${encodeURIComponent(sid)}`);
  if (!response.ok) {
    throw new Error(`Failed to get fields: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Load persisted chat history for a session.
 */
export async function getChatHistory(
  limit: number = 80,
  sessionId?: string
): Promise<{ session_id: string; messages: ChatHistoryMessage[] }> {
  const sid = resolveSessionId(sessionId);
  const params = new URLSearchParams({
    session_id: sid,
    limit: String(limit),
  });
  const response = await fetch(`${getAtlanteanApiBase()}/chat/history?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Failed to get chat history: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Trigger a learning event
 * 
 * Call this when user provides feedback or interactions complete.
 * This is how the intelligence learns!
 * 
 * @param event Type of learning event
 * @param data Event-specific data
 */
export async function triggerLearningEvent(
  event: LearningEventType,
  data: Record<string, any> = {},
  sessionId?: string
): Promise<{ success: boolean; status: AtlanteanStatus }> {
  const sid = resolveSessionId(sessionId);
  const response = await fetch(`${getAtlanteanApiBase()}/learning-event`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ event, data, session_id: sid }),
  });
  
  if (!response.ok) {
    throw new Error(`Learning event failed: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Store a simulation in cold memory
 */
export async function storeSimulation(
  simulation: any,
  confidence: number = 0.5,
  sessionId?: string
): Promise<{ success: boolean }> {
  const sid = resolveSessionId(sessionId);
  const response = await fetch(`${getAtlanteanApiBase()}/simulation/store`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ simulation, confidence, session_id: sid }),
  });
  
  if (!response.ok) {
    throw new Error(`Failed to store simulation: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * List all stored simulations directly from backend (reliable, no embedding)
 */
export async function recallSimulations(
  searchQuery: string,
  limit: number = 50,
  sessionId?: string
): Promise<any[]> {
  const sid = resolveSessionId(sessionId);
  // Prefer /list (direct Redis listing). Fallback to /recall for backward compatibility.
  const listResponse = await fetch(
    `${getAtlanteanApiBase()}/simulation/list?limit=${limit}&session_id=${encodeURIComponent(sid)}`
  );
  if (listResponse.ok) {
    const data = await listResponse.json();
    return data.simulations || [];
  }

  if (listResponse.status !== 404) {
    throw new Error(`Failed to list simulations: ${listResponse.statusText}`);
  }

  const recallResponse = await fetch(`${getAtlanteanApiBase()}/simulation/recall`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ query: searchQuery, limit, session_id: sid }),
  });

  if (!recallResponse.ok) {
    throw new Error(`Failed to recall simulations: ${recallResponse.statusText}`);
  }

  const recallData = await recallResponse.json();
  return recallData.simulations || [];
}

/**
 * Create a labeled snapshot for Neural Archives
 */
export async function createSnapshot(
  label?: string,
  sessionId?: string
): Promise<{ snapshot: any }> {
  const sid = resolveSessionId(sessionId);
  const response = await fetch(`${getAtlanteanApiBase()}/snapshot`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ label, session_id: sid }),
  });
  
  if (!response.ok) {
    throw new Error(`Failed to create snapshot: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * List indexed snapshots for Neural Archives
 */
export async function listSnapshots(
  limit: number = 50,
  sessionId?: string
): Promise<{ session_id: string; snapshots: AtlanteanSnapshotRecord[] }> {
  const sid = resolveSessionId(sessionId);
  const params = new URLSearchParams({
    session_id: sid,
    limit: String(limit),
  });

  const response = await fetch(`${getAtlanteanApiBase()}/snapshots?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Failed to list snapshots: ${response.statusText}`);
  }

  return response.json();
}

/**
 * Restore hot-memory state from a saved snapshot
 */
export async function restoreSnapshot(
  snapshotId: string,
  sessionId?: string
): Promise<{ success: boolean; session_id: string; snapshot_id: string; status: AtlanteanStatus }> {
  const sid = resolveSessionId(sessionId);
  const response = await fetch(`${getAtlanteanApiBase()}/snapshot/restore`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      snapshot_id: snapshotId,
      session_id: sid,
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to restore snapshot: ${response.statusText}`);
  }

  return response.json();
}

/**
 * Delete a snapshot from archive index
 */
export async function deleteSnapshot(
  snapshotId: string,
  sessionId?: string
): Promise<{ success: boolean; session_id: string; snapshot_id: string; remaining: number }> {
  const sid = resolveSessionId(sessionId);
  const response = await fetch(`${getAtlanteanApiBase()}/snapshot/delete`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      snapshot_id: snapshotId,
      session_id: sid,
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to delete snapshot: ${response.statusText}`);
  }

  return response.json();
}

/**
 * List cold-memory manifests for detachable memory management
 */
export async function listColdManifests(
  includeDetached: boolean = false,
  sessionId?: string
): Promise<{ session_id: string; manifests: ColdManifest[] }> {
  const sid = resolveSessionId(sessionId);
  const params = new URLSearchParams();
  if (includeDetached) params.set('include_detached', 'true');
  params.set('session_id', sid);
  const suffix = params.toString() ? `?${params.toString()}` : '';

  const response = await fetch(`${getAtlanteanApiBase()}/cold/manifests${suffix}`);
  if (!response.ok) {
    throw new Error(`Failed to list cold manifests: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Export a detachable cold-memory manifest bundle
 */
export async function exportColdManifest(
  manifestId: string,
  sessionId?: string
): Promise<{ session_id: string; manifest: any }> {
  const sid = resolveSessionId(sessionId);
  const params = new URLSearchParams({ manifest_id: manifestId });
  params.set('session_id', sid);

  const response = await fetch(`${getAtlanteanApiBase()}/cold/manifest/export?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Failed to export cold manifest: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Import a detachable cold-memory manifest bundle
 */
export async function importColdManifest(
  manifest: any,
  sessionId?: string
): Promise<{ session_id: string; result: any }> {
  const sid = resolveSessionId(sessionId);
  const body: any = { manifest };
  body.session_id = sid;

  const response = await fetch(`${getAtlanteanApiBase()}/cold/manifest/import`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw new Error(`Failed to import cold manifest: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Tombstone a cold-memory item while preserving lineage
 */
export async function tombstoneColdItem(
  itemId: string,
  reason: string = 'manual',
  sessionId?: string
): Promise<{ success: boolean; session_id: string; item_id: string; reason: string }> {
  const sid = resolveSessionId(sessionId);
  const body: any = {
    item_id: itemId,
    reason,
    session_id: sid,
  };

  const response = await fetch(`${getAtlanteanApiBase()}/cold/tombstone`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });
  if (!response.ok) {
    throw new Error(`Failed to tombstone cold item: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Prepare sync package for multi-device
 */
export async function prepareSyncPackage(): Promise<{ package: any }> {
  const response = await fetch(`${getAtlanteanApiBase()}/sync/prepare`);
  if (!response.ok) {
    throw new Error(`Failed to prepare sync: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Merge sync package from another device
 */
export async function mergeSyncPackage(
  syncPackage: any,
  strategy: 'conservative' | 'field_average' | 'last_write_wins' | 'max_energy' | 'max_plasticity' = 'conservative'
): Promise<{ success: boolean; status: AtlanteanStatus; sync?: any }> {
  const response = await fetch(`${getAtlanteanApiBase()}/sync/merge`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ package: syncPackage, strategy }),
  });
  
  if (!response.ok) {
    throw new Error(`Failed to merge sync: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Reset intelligence state (for testing/debugging)
 */
export async function resetIntelligence(): Promise<{ success: boolean }> {
  const response = await fetch(`${getAtlanteanApiBase()}/reset`, {
    method: 'POST',
  });
  
  if (!response.ok) {
    throw new Error(`Failed to reset: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Manually save intelligence state
 */
export async function saveState(): Promise<{ success: boolean }> {
  const response = await fetch(`${getAtlanteanApiBase()}/save`, {
    method: 'POST',
  });
  
  if (!response.ok) {
    throw new Error(`Failed to save: ${response.statusText}`);
  }
  
  return response.json();
}

/**
 * Check if Atlantean backend is running
 */
export async function checkHealth(): Promise<boolean> {
  try {
    const response = await fetch(getAtlanteanHealthUrl());
    return response.ok;
  } catch {
    return false;
  }
}

/**
 * Deterministic replay integrity proof (ledger-derived state hash vs live state hash)
 */
export async function replayIntegrityProof(
  sessionId?: string
): Promise<ReplayIntegrityProof> {
  const sid = resolveSessionId(sessionId);
  const params = new URLSearchParams();
  params.set('session_id', sid);
  const suffix = params.toString() ? `?${params.toString()}` : '';

  const response = await fetch(`${getAtlanteanApiBase()}/integrity/replay${suffix}`);
  if (!response.ok) {
    throw new Error(`Failed replay proof: ${response.statusText}`);
  }
  return response.json();
}

/**
 * Export complete signed intelligence state for user-owned portability.
 */
export async function exportSoulFile(
  sessionId?: string
): Promise<{ bundle: SoulFileBundle }> {
  const sid = resolveSessionId(sessionId);
  const params = new URLSearchParams();
  params.set('session_id', sid);
  const suffix = params.toString() ? `?${params.toString()}` : '';

  const response = await fetch(`${getAtlanteanApiBase()}/export${suffix}`);
  if (!response.ok) {
    throw new Error(`Failed to export soul file: ${response.statusText}`);
  }
  return response.json();
}
